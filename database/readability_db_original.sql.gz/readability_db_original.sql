--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.15
-- Dumped by pg_dump version 13.21 (Debian 13.21-0+deb11u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: find_vote_by_experiment_session_and_snippet_pair(bigint, bigint); Type: FUNCTION; Schema: public; Owner: elsendi
--

CREATE FUNCTION public.find_vote_by_experiment_session_and_snippet_pair(e bigint, s bigint) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
declare vote_id integer;
begin
	select v.vote_id into vote_id
	from votes v
	where v.experiment_session_id = $1
		and v.snippet_pair_id = $2
	order by v.arrival_time desc, v.vote_id desc
	limit 1;

	return vote_id;
end;
$_$;


ALTER FUNCTION public.find_vote_by_experiment_session_and_snippet_pair(e bigint, s bigint) OWNER TO elsendi;

--
-- Name: insert_pair(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: elsendi
--

CREATE FUNCTION public.insert_pair(hash_code character varying, snippet_a_content character varying, snippet_b_content character varying, most_readable character varying) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE
	a_id INTEGER;
	b_id INTEGER;
BEGIN
	IF NOT EXISTS(SELECT hash FROM snippet_pairs WHERE hash = $1) THEN
		INSERT INTO snippets(content) VALUES (snippet_a_content);
		SELECT currval('snippets_snippet_id_seq') INTO a_id;

		INSERT INTO snippets(content) VALUES (snippet_b_content);
		SELECT currval('snippets_snippet_id_seq') INTO b_id;

		INSERT INTO snippet_pairs(hash, snippet_a, snippet_b, most_readable, active)
		VALUES(hash_code, a_id, b_id, most_readable, true);
	END IF;
END;
$_$;


ALTER FUNCTION public.insert_pair(hash_code character varying, snippet_a_content character varying, snippet_b_content character varying, most_readable character varying) OWNER TO elsendi;

--
-- Name: label_snippet_with_category(character, character varying); Type: FUNCTION; Schema: public; Owner: elsendi
--

CREATE FUNCTION public.label_snippet_with_category(_snippet_hash character, _category_label character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
	pre_existent_categories int;
	pre_existent_associations int;
	snippet_pair_id_var int;
	category_id_var int;
begin
	if (select count(*) from snippet_pairs where hash = _snippet_hash) = 0 then
		raise 'No snippet pair with the informed hash';
	end if;

	pre_existent_categories := (select count(*) from categories where label = _category_label);
	if pre_existent_categories = 0 then
		insert into categories(label) values(_category_label);
	end if;

	snippet_pair_id_var := (select sp.snippet_pair_id from snippet_pairs sp where hash = _snippet_hash); 
	category_id_var := (select c.category_id from categories c where label = _category_label);

	pre_existent_associations := (
		select count(spc.*) 
		from snippet_pairs_categories spc 
		where spc.snippet_pair_id = snippet_pair_id_var
			and spc.category_id = category_id_var
	); 

	if pre_existent_associations = 0 then
		insert into snippet_pairs_categories (snippet_pair_id, category_id) 
		values (snippet_pair_id_var, category_id_var);
	end if; 
end
$$;


ALTER FUNCTION public.label_snippet_with_category(_snippet_hash character, _category_label character varying) OWNER TO elsendi;

--
-- Name: loop_test(); Type: FUNCTION; Schema: public; Owner: elsendi
--

CREATE FUNCTION public.loop_test() RETURNS TABLE(experiment_session_id integer)
    LANGUAGE plpgsql
    AS $$
begin
	for experiment_session_id in
		select e.experiment_session_id
		from experiment_sessions e
		where e.start_time > '20170801'
	loop
		return next;
	end loop;

end;
$$;


ALTER FUNCTION public.loop_test() OWNER TO elsendi;

--
-- Name: loop_test2(integer); Type: FUNCTION; Schema: public; Owner: elsendi
--

CREATE FUNCTION public.loop_test2(_snippet_pair_id integer) RETURNS TABLE(experiment_session_id integer, total bigint, divergents bigint)
    LANGUAGE sql
    AS $_$
	select e.experiment_session_id,
		(select 
			count(tot.*) 
			from votes tot 
			where tot.experiment_session_id = e.experiment_session_id
				and tot.snippet_pair_id = $1
				and tot.last_vote=true) as total,
		(select
			count(div.*)
			from votes div
				inner join snippet_pairs sp 
				on div.snippet_pair_id = sp.snippet_pair_id
					and div.snippet_order <> sp.most_readable
			where div.experiment_session_id = e.experiment_session_id
				and div.snippet_pair_id = $1
				and div.last_vote=true) as divergents
	from experiment_sessions e
	where e.start_time > '20170801'
		and exists(
			select v.vote_id 
			from votes v 
			where v.experiment_session_id = e.experiment_session_id);
$_$;


ALTER FUNCTION public.loop_test2(_snippet_pair_id integer) OWNER TO elsendi;

SET default_tablespace = '';

--
-- Name: categories; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.categories (
    category_id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.categories OWNER TO elsendi;

--
-- Name: categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: elsendi
--

CREATE SEQUENCE public.categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_category_id_seq OWNER TO elsendi;

--
-- Name: categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: elsendi
--

ALTER SEQUENCE public.categories_category_id_seq OWNED BY public.categories.category_id;


--
-- Name: client_headers; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.client_headers (
    client_header_id integer NOT NULL,
    json_data text
);


ALTER TABLE public.client_headers OWNER TO elsendi;

--
-- Name: client_headers_client_header_id_seq; Type: SEQUENCE; Schema: public; Owner: elsendi
--

CREATE SEQUENCE public.client_headers_client_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_headers_client_header_id_seq OWNER TO elsendi;

--
-- Name: client_headers_client_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: elsendi
--

ALTER SEQUENCE public.client_headers_client_header_id_seq OWNED BY public.client_headers.client_header_id;


--
-- Name: experiment_sessions; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.experiment_sessions (
    experiment_session_id integer NOT NULL,
    profile_id integer,
    working_set_id integer,
    client_header_id integer,
    jsession_id character varying,
    ga_client_cookie character varying,
    locale character varying,
    comments character varying,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    origin character varying
);


ALTER TABLE public.experiment_sessions OWNER TO elsendi;

--
-- Name: experiment_sessions_experiment_session_id_seq; Type: SEQUENCE; Schema: public; Owner: elsendi
--

CREATE SEQUENCE public.experiment_sessions_experiment_session_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.experiment_sessions_experiment_session_id_seq OWNER TO elsendi;

--
-- Name: experiment_sessions_experiment_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: elsendi
--

ALTER SEQUENCE public.experiment_sessions_experiment_session_id_seq OWNED BY public.experiment_sessions.experiment_session_id;


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.profiles (
    profile_id integer NOT NULL,
    name character varying,
    email character varying,
    programming_experience_time real,
    java_programming_experience_time real,
    floss_experience_time real,
    annotations_experience_time real,
    age character varying,
    years_in_school character varying,
    gender character(1),
    programming_languages character varying,
    natural_languages character varying,
    operating_systems character varying,
    english_confort_level smallint,
    perceived_readability_level smallint,
    learning_profile character varying,
    professional_profile character varying,
    CONSTRAINT profiles_english_confort_level_check CHECK (((english_confort_level >= 0) AND (english_confort_level <= 4))),
    CONSTRAINT profiles_gender_check CHECK ((gender = ANY (ARRAY['M'::bpchar, 'F'::bpchar]))),
    CONSTRAINT profiles_perceived_readability_level_check CHECK (((perceived_readability_level >= 0) AND (perceived_readability_level <= 4)))
);


ALTER TABLE public.profiles OWNER TO elsendi;

--
-- Name: profiles_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: elsendi
--

CREATE SEQUENCE public.profiles_profile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.profiles_profile_id_seq OWNER TO elsendi;

--
-- Name: profiles_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: elsendi
--

ALTER SEQUENCE public.profiles_profile_id_seq OWNED BY public.profiles.profile_id;


--
-- Name: session_events; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.session_events (
    session_event_id integer NOT NULL,
    experiment_session_id integer NOT NULL,
    arrival_time timestamp with time zone NOT NULL,
    content character varying NOT NULL
);


ALTER TABLE public.session_events OWNER TO elsendi;

--
-- Name: session_events_session_event_id_seq; Type: SEQUENCE; Schema: public; Owner: elsendi
--

CREATE SEQUENCE public.session_events_session_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.session_events_session_event_id_seq OWNER TO elsendi;

--
-- Name: session_events_session_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: elsendi
--

ALTER SEQUENCE public.session_events_session_event_id_seq OWNED BY public.session_events.session_event_id;


--
-- Name: snippet_pairs; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.snippet_pairs (
    snippet_pair_id integer NOT NULL,
    hash character(32) NOT NULL,
    snippet_a integer NOT NULL,
    snippet_b integer NOT NULL,
    most_readable character(1) NOT NULL,
    active boolean DEFAULT false NOT NULL,
    CONSTRAINT snippet_pairs_most_readable_check CHECK ((most_readable = ANY (ARRAY['A'::bpchar, 'B'::bpchar])))
);


ALTER TABLE public.snippet_pairs OWNER TO elsendi;

--
-- Name: snippet_pairs_categories; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.snippet_pairs_categories (
    snippet_pair_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.snippet_pairs_categories OWNER TO elsendi;

--
-- Name: snippet_pairs_snippet_pair_id_seq; Type: SEQUENCE; Schema: public; Owner: elsendi
--

CREATE SEQUENCE public.snippet_pairs_snippet_pair_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.snippet_pairs_snippet_pair_id_seq OWNER TO elsendi;

--
-- Name: snippet_pairs_snippet_pair_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: elsendi
--

ALTER SEQUENCE public.snippet_pairs_snippet_pair_id_seq OWNED BY public.snippet_pairs.snippet_pair_id;


--
-- Name: snippets; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.snippets (
    snippet_id integer NOT NULL,
    content character varying NOT NULL
);


ALTER TABLE public.snippets OWNER TO elsendi;

--
-- Name: snippets_snippet_id_seq; Type: SEQUENCE; Schema: public; Owner: elsendi
--

CREATE SEQUENCE public.snippets_snippet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.snippets_snippet_id_seq OWNER TO elsendi;

--
-- Name: snippets_snippet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: elsendi
--

ALTER SEQUENCE public.snippets_snippet_id_seq OWNED BY public.snippets.snippet_id;


--
-- Name: votes; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.votes (
    vote_id integer NOT NULL,
    experiment_session_id integer NOT NULL,
    snippet_pair_id integer NOT NULL,
    snippet_order character(1),
    arrival_time timestamp with time zone NOT NULL,
    comments character varying,
    strength character varying,
    other_categorical_variables character varying,
    last_vote boolean DEFAULT false NOT NULL
);


ALTER TABLE public.votes OWNER TO elsendi;

--
-- Name: votes_vote_id_seq; Type: SEQUENCE; Schema: public; Owner: elsendi
--

CREATE SEQUENCE public.votes_vote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.votes_vote_id_seq OWNER TO elsendi;

--
-- Name: votes_vote_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: elsendi
--

ALTER SEQUENCE public.votes_vote_id_seq OWNED BY public.votes.vote_id;


--
-- Name: working_sets; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.working_sets (
    working_set_id integer NOT NULL
);


ALTER TABLE public.working_sets OWNER TO elsendi;

--
-- Name: working_sets_snippet_pairs; Type: TABLE; Schema: public; Owner: elsendi
--

CREATE TABLE public.working_sets_snippet_pairs (
    working_set_id integer NOT NULL,
    snippet_pair_id integer NOT NULL,
    presentation_order smallint NOT NULL
);


ALTER TABLE public.working_sets_snippet_pairs OWNER TO elsendi;

--
-- Name: working_sets_working_set_id_seq; Type: SEQUENCE; Schema: public; Owner: elsendi
--

CREATE SEQUENCE public.working_sets_working_set_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.working_sets_working_set_id_seq OWNER TO elsendi;

--
-- Name: working_sets_working_set_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: elsendi
--

ALTER SEQUENCE public.working_sets_working_set_id_seq OWNED BY public.working_sets.working_set_id;


--
-- Name: categories category_id; Type: DEFAULT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.categories ALTER COLUMN category_id SET DEFAULT nextval('public.categories_category_id_seq'::regclass);


--
-- Name: client_headers client_header_id; Type: DEFAULT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.client_headers ALTER COLUMN client_header_id SET DEFAULT nextval('public.client_headers_client_header_id_seq'::regclass);


--
-- Name: experiment_sessions experiment_session_id; Type: DEFAULT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.experiment_sessions ALTER COLUMN experiment_session_id SET DEFAULT nextval('public.experiment_sessions_experiment_session_id_seq'::regclass);


--
-- Name: profiles profile_id; Type: DEFAULT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.profiles ALTER COLUMN profile_id SET DEFAULT nextval('public.profiles_profile_id_seq'::regclass);


--
-- Name: session_events session_event_id; Type: DEFAULT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.session_events ALTER COLUMN session_event_id SET DEFAULT nextval('public.session_events_session_event_id_seq'::regclass);


--
-- Name: snippet_pairs snippet_pair_id; Type: DEFAULT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.snippet_pairs ALTER COLUMN snippet_pair_id SET DEFAULT nextval('public.snippet_pairs_snippet_pair_id_seq'::regclass);


--
-- Name: snippets snippet_id; Type: DEFAULT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.snippets ALTER COLUMN snippet_id SET DEFAULT nextval('public.snippets_snippet_id_seq'::regclass);


--
-- Name: votes vote_id; Type: DEFAULT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.votes ALTER COLUMN vote_id SET DEFAULT nextval('public.votes_vote_id_seq'::regclass);


--
-- Name: working_sets working_set_id; Type: DEFAULT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.working_sets ALTER COLUMN working_set_id SET DEFAULT nextval('public.working_sets_working_set_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.categories (category_id, label) FROM stdin;
1	cat1
\.


--
-- Data for Name: client_headers; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.client_headers (client_header_id, json_data) FROM stdin;
1	{"User-Agent":["Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0"],"X-Forwarded-For":["::1"],"Accept-Language":["en-US,en;q=0.5"],"XX-Remote-Addr":"127.0.0.1"}
2	{"User-Agent":["Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0"],"X-Forwarded-For":["::1"],"Accept-Language":["en-US,en;q=0.5"],"XX-Remote-Addr":"127.0.0.1"}
3	{"User-Agent":["Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0"],"X-Forwarded-For":["::1"],"Accept-Language":["en-US,en;q=0.5"],"XX-Remote-Addr":"127.0.0.1"}
4	{"User-Agent":["Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0"],"X-Forwarded-For":["::1"],"Accept-Language":["en-US,en;q=0.5"],"XX-Remote-Addr":"127.0.0.1"}
\.


--
-- Data for Name: experiment_sessions; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.experiment_sessions (experiment_session_id, profile_id, working_set_id, client_header_id, jsession_id, ga_client_cookie, locale, comments, start_time, end_time, origin) FROM stdin;
1	\N	1	1	F23899505C9DD1BD01174832FBF7F27E	GA1.1.2044923163.1575908876	en	\N	2020-07-15 11:44:51.941-03	\N	\N
2	\N	2	2	1FC307C318D8010328B8E75263135938	GA1.1.2044923163.1575908876	en	\N	2020-07-15 12:01:10.656-03	\N	\N
3	\N	3	3	54049508F2051A9BBF33C92713B31EA2	GA1.1.2044923163.1575908876	en	\N	2020-07-15 12:02:21.926-03	\N	\N
4	1	4	4	043DC5888A8D7EEEC9A5E252936A3E80	GA1.1.2044923163.1575908876	pt	\N	2020-07-15 12:03:51.631-03	2020-07-15 12:05:38-03	\N
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.profiles (profile_id, name, email, programming_experience_time, java_programming_experience_time, floss_experience_time, annotations_experience_time, age, years_in_school, gender, programming_languages, natural_languages, operating_systems, english_confort_level, perceived_readability_level, learning_profile, professional_profile) FROM stdin;
1			0	0	0	-1	\N	\N	\N	\N	\N	\N	0	0	\N	\N
\.


--
-- Data for Name: session_events; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.session_events (session_event_id, experiment_session_id, arrival_time, content) FROM stdin;
1	1	2020-07-15 11:44:55.197-03	{"sender":"InstructionsController","method":"init"}
2	1	2020-07-15 11:44:55.197-03	{"sender":"InstructionsController","tag":{"width":1440,"height":599}}
3	1	2020-07-15 11:44:58.294-03	{"sender":"InstructionsController","method":"goNextStep"}
4	1	2020-07-15 11:45:10.185-03	{"sender":"PairsController","method":"vote(a); $scope.pairIndex = 1","tag":{"width":1920,"height":770}}
5	2	2020-07-15 12:01:14.535-03	{"sender":"InstructionsController","tag":{"width":1920,"height":599}}
6	2	2020-07-15 12:01:14.535-03	{"sender":"InstructionsController","method":"init"}
7	2	2020-07-15 12:01:17.035-03	{"sender":"InstructionsController","method":"goNextStep"}
8	2	2020-07-15 12:01:23.085-03	{"sender":"PairsController","method":"showSnippetPair","tag":{"index":2}}
9	2	2020-07-15 12:01:27.941-03	{"sender":"PairsController","method":"finalizeVotation"}
10	3	2020-07-15 12:02:24.284-03	{"sender":"InstructionsController","tag":{"width":1920,"height":599}}
11	3	2020-07-15 12:02:24.284-03	{"sender":"InstructionsController","method":"init"}
12	3	2020-07-15 12:02:26.396-03	{"sender":"InstructionsController","method":"goNextStep"}
13	3	2020-07-15 12:02:29.254-03	{"sender":"PairsController","method":"showSnippetPair","tag":{"index":2}}
14	3	2020-07-15 12:02:33.38-03	{"sender":"PairsController","method":"finalizeVotation"}
15	4	2020-07-15 12:03:54.162-03	{"sender":"InstructionsController","tag":{"width":1920,"height":652}}
16	4	2020-07-15 12:03:54.163-03	{"sender":"InstructionsController","method":"init"}
17	4	2020-07-15 12:03:56.129-03	{"sender":"InstructionsController","method":"goNextStep"}
18	4	2020-07-15 12:03:58.225-03	{"sender":"PairsController","method":"vote(a); $scope.pairIndex = 1","tag":{"width":1920,"height":770}}
19	4	2020-07-15 12:04:00.799-03	{"sender":"PairsController","method":"showSnippetPair","tag":{"index":2}}
20	4	2020-07-15 12:04:02.32-03	{"sender":"PairsController","method":"vote(b); $scope.pairIndex = 2","tag":{"width":1920,"height":770}}
21	4	2020-07-15 12:04:06.882-03	{"sender":"PairsController","method":"finalizeVotation"}
22	4	2020-07-15 12:05:35.701-03	{"sender":"CommentsController","method":"initialize"}
23	4	2020-07-15 12:05:37.989-03	{"sender":"CommentsController","method":"goNextStep"}
\.


--
-- Data for Name: snippet_pairs; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.snippet_pairs (snippet_pair_id, hash, snippet_a, snippet_b, most_readable, active) FROM stdin;
1	0ad7e46f95a99b213aa0821f5b977061	1	2	A	t
2	b89791a190451d262645d2ae3a48e6b4	3	4	B	t
\.


--
-- Data for Name: snippet_pairs_categories; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.snippet_pairs_categories (snippet_pair_id, category_id) FROM stdin;
1	1
2	1
\.


--
-- Data for Name: snippets; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.snippets (snippet_id, content) FROM stdin;
1	<div class="highlight"><pre><span></span><span class="lineno">1 </span><span class="kn">package</span> <span class="nn">org.adheres</span><span class="o">;</span>\n<span class="lineno">2 </span>\n<span class="lineno">3 </span><span class="kn">import</span> <span class="nn">org.adheres.Annotation</span><span class="o">;</span>\n<span class="lineno">4 </span>\n<span class="lineno">5 </span><span class="nd">@Annotation</span>\n<span class="lineno">6 </span><span class="kd">class</span> <span class="nc">Test</span> <span class="o">{</span>\n<span class="lineno">7 </span><span class="o">}</span>\n</pre></div>\n
2	<div class="highlight"><pre><span></span><span class="lineno linehl"> 1 </span><span class="kn">package</span> <span class="nn">org.diverges</span><span class="o">;</span>\n<span class="lineno">2 </span>\n<span class="lineno">3 </span><span class="kd">class</span> <span class="nc">Test</span> <span class="o">{</span>\n<span class="lineno">4 </span><span class="o">}</span>\n</pre></div>\n
3	<div class="highlight"><pre><span></span><span class="lineno linehl"> 1 </span><span class="kn">package</span> <span class="nn">org.diverges</span><span class="o">;</span>\n<span class="lineno">2 </span>\n<span class="lineno">3 </span><span class="kd">class</span> <span class="nc">Test</span> <span class="o">{</span>\n<span class="lineno">4 </span><span class="o">}</span>\n</pre></div>\n
4	<div class="highlight"><pre><span></span><span class="lineno">1 </span><span class="kn">package</span> <span class="nn">org.adheres</span><span class="o">;</span>\n<span class="lineno">2 </span>\n<span class="lineno">3 </span><span class="kn">import</span> <span class="nn">org.adheres.Annotation</span><span class="o">;</span>\n<span class="lineno">4 </span>\n<span class="lineno">5 </span><span class="nd">@Annotation2</span>\n<span class="lineno">6 </span><span class="kd">class</span> <span class="nc">Test</span> <span class="o">{</span>\n<span class="lineno">7 </span><span class="o">}</span>\n</pre></div>\n
\.


--
-- Data for Name: votes; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.votes (vote_id, experiment_session_id, snippet_pair_id, snippet_order, arrival_time, comments, strength, other_categorical_variables, last_vote) FROM stdin;
1	1	2	a	2020-07-15 11:45:10.25-03	\N	3	\N	t
2	4	1	a	2020-07-15 12:03:58.305-03	.	1	\N	t
3	4	2	b	2020-07-15 12:04:02.332-03	.	4	\N	t
\.


--
-- Data for Name: working_sets; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.working_sets (working_set_id) FROM stdin;
1
2
3
4
\.


--
-- Data for Name: working_sets_snippet_pairs; Type: TABLE DATA; Schema: public; Owner: elsendi
--

COPY public.working_sets_snippet_pairs (working_set_id, snippet_pair_id, presentation_order) FROM stdin;
1	1	1
1	2	0
2	1	1
2	2	0
3	1	1
3	2	0
4	2	1
4	1	0
\.


--
-- Name: categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elsendi
--

SELECT pg_catalog.setval('public.categories_category_id_seq', 1, true);


--
-- Name: client_headers_client_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elsendi
--

SELECT pg_catalog.setval('public.client_headers_client_header_id_seq', 4, true);


--
-- Name: experiment_sessions_experiment_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elsendi
--

SELECT pg_catalog.setval('public.experiment_sessions_experiment_session_id_seq', 4, true);


--
-- Name: profiles_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elsendi
--

SELECT pg_catalog.setval('public.profiles_profile_id_seq', 1, true);


--
-- Name: session_events_session_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elsendi
--

SELECT pg_catalog.setval('public.session_events_session_event_id_seq', 23, true);


--
-- Name: snippet_pairs_snippet_pair_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elsendi
--

SELECT pg_catalog.setval('public.snippet_pairs_snippet_pair_id_seq', 2, true);


--
-- Name: snippets_snippet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elsendi
--

SELECT pg_catalog.setval('public.snippets_snippet_id_seq', 4, true);


--
-- Name: votes_vote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elsendi
--

SELECT pg_catalog.setval('public.votes_vote_id_seq', 3, true);


--
-- Name: working_sets_working_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elsendi
--

SELECT pg_catalog.setval('public.working_sets_working_set_id_seq', 4, true);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (category_id);


--
-- Name: client_headers client_headers_pkey; Type: CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.client_headers
    ADD CONSTRAINT client_headers_pkey PRIMARY KEY (client_header_id);


--
-- Name: experiment_sessions experiment_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.experiment_sessions
    ADD CONSTRAINT experiment_sessions_pkey PRIMARY KEY (experiment_session_id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (profile_id);


--
-- Name: session_events session_events_pkey; Type: CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.session_events
    ADD CONSTRAINT session_events_pkey PRIMARY KEY (session_event_id);


--
-- Name: snippet_pairs snippet_pairs_pkey; Type: CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.snippet_pairs
    ADD CONSTRAINT snippet_pairs_pkey PRIMARY KEY (snippet_pair_id);


--
-- Name: snippets snippets_pkey; Type: CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.snippets
    ADD CONSTRAINT snippets_pkey PRIMARY KEY (snippet_id);


--
-- Name: votes votes_pkey; Type: CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_pkey PRIMARY KEY (vote_id);


--
-- Name: working_sets working_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.working_sets
    ADD CONSTRAINT working_sets_pkey PRIMARY KEY (working_set_id);


--
-- Name: ux_categories_label; Type: INDEX; Schema: public; Owner: elsendi
--

CREATE UNIQUE INDEX ux_categories_label ON public.categories USING btree (label);


--
-- Name: ux_snippet_pairs_categories; Type: INDEX; Schema: public; Owner: elsendi
--

CREATE UNIQUE INDEX ux_snippet_pairs_categories ON public.snippet_pairs_categories USING btree (snippet_pair_id, category_id);


--
-- Name: experiment_sessions experiment_sessions_client_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.experiment_sessions
    ADD CONSTRAINT experiment_sessions_client_header_id_fkey FOREIGN KEY (client_header_id) REFERENCES public.client_headers(client_header_id);


--
-- Name: experiment_sessions experiment_sessions_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.experiment_sessions
    ADD CONSTRAINT experiment_sessions_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(profile_id);


--
-- Name: experiment_sessions experiment_sessions_working_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.experiment_sessions
    ADD CONSTRAINT experiment_sessions_working_set_id_fkey FOREIGN KEY (working_set_id) REFERENCES public.working_sets(working_set_id);


--
-- Name: session_events session_events_experiment_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.session_events
    ADD CONSTRAINT session_events_experiment_session_id_fkey FOREIGN KEY (experiment_session_id) REFERENCES public.experiment_sessions(experiment_session_id);


--
-- Name: snippet_pairs_categories snippet_pairs_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.snippet_pairs_categories
    ADD CONSTRAINT snippet_pairs_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(category_id);


--
-- Name: snippet_pairs_categories snippet_pairs_categories_snippet_pair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.snippet_pairs_categories
    ADD CONSTRAINT snippet_pairs_categories_snippet_pair_id_fkey FOREIGN KEY (snippet_pair_id) REFERENCES public.snippet_pairs(snippet_pair_id);


--
-- Name: snippet_pairs snippet_pairs_snippet_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.snippet_pairs
    ADD CONSTRAINT snippet_pairs_snippet_a_fkey FOREIGN KEY (snippet_a) REFERENCES public.snippets(snippet_id);


--
-- Name: snippet_pairs snippet_pairs_snippet_b_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.snippet_pairs
    ADD CONSTRAINT snippet_pairs_snippet_b_fkey FOREIGN KEY (snippet_b) REFERENCES public.snippets(snippet_id);


--
-- Name: votes votes_experiment_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_experiment_session_id_fkey FOREIGN KEY (experiment_session_id) REFERENCES public.experiment_sessions(experiment_session_id);


--
-- Name: votes votes_snippet_pair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_snippet_pair_id_fkey FOREIGN KEY (snippet_pair_id) REFERENCES public.snippet_pairs(snippet_pair_id);


--
-- Name: working_sets_snippet_pairs working_sets_snippet_pairs_snippet_pair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.working_sets_snippet_pairs
    ADD CONSTRAINT working_sets_snippet_pairs_snippet_pair_id_fkey FOREIGN KEY (snippet_pair_id) REFERENCES public.snippet_pairs(snippet_pair_id);


--
-- Name: working_sets_snippet_pairs working_sets_snippet_pairs_working_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elsendi
--

ALTER TABLE ONLY public.working_sets_snippet_pairs
    ADD CONSTRAINT working_sets_snippet_pairs_working_set_id_fkey FOREIGN KEY (working_set_id) REFERENCES public.working_sets(working_set_id);


--
-- PostgreSQL database dump complete
--

